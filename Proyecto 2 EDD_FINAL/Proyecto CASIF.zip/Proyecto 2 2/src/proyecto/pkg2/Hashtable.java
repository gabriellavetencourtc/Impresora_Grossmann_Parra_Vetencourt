/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto.pkg2;

import javax.swing.JOptionPane;

/**
 *
 * @author daniela
 */
public class Hashtable {

    private int capacity;
    private Object[] keys;
    private Object[] values;
    private int size;
    private int index;

    public Hashtable() {
        this.capacity = 100;
        this.keys = new Object[capacity];
        this.values = new Object[capacity];
        this.size = 0;
        this.index = -1;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public Object[] getKeys() {
        return keys;
    }

    public void setKeys(Object[] keys) {
        this.keys = keys;
    }

    public Object[] getValues() {
        return values;
    }

    public void setValues(Object[] values) {
        this.values = values;
    }

    private int hash(Object key) {
        return Math.abs(key.hashCode() % capacity);
    }

    public void put(Object key, Object value) {
        int index = hash(key);
        keys[index] = key;
        values[index] = value;
        size++;
    }

    public Object get(Object key) {
        int index = hash(key);

        if (keys[index] != null && keys[index].equals(key)) {
            this.index = index;
            return values[index];
        }
        return null;
    }

    public Object getKey(Object nombreUsuario) {
        for (int i = 0; i < keys.length; i++) {
            if (keys[i] != null && keys[i] instanceof Usuario) {
                Usuario us = (Usuario) keys[i];
                if (us.getNombre().equals(nombreUsuario)) {
                    return keys[i]; // Devuelve el usuario si se encuentra
                }
            }
        }
        return null; // Si no se encuentra el usuario
    }

    public void printHashtable() {
        System.out.println("Hashtable:");
        for (int i = 0; i < capacity; i++) {
            if (keys[i] != null) {
                Lista<Documento> ldoc = (Lista) values[i];
                this.index = i;
                Usuario us = (Usuario) keys[i];
                System.out.println("Index: " + i + ", Key: " + us.getNombre() + ", Value: \n" + ldoc.ImprimirDocPrueba());
            }
        }
    }
    //Verificar si el key está en el hashtable   

    public boolean contieneUsuario(String nombreUsuario) {
        for (int i = 0; i < capacity; i++) {

            if (keys[i] != null && keys[i] instanceof Usuario) {
                Usuario us = (Usuario) keys[i];
                if (us.getNombre().equals(nombreUsuario)) {
                    return true;
                }
            }
        }
        return false;
    }

    public void remove(String nombreUsuario) {
        int index = -1;

        for (int i = 0; i < capacity; i++) {
            if (keys[i] != null && keys[i] instanceof Usuario) {
                Usuario usuario = (Usuario) keys[i];
                if (usuario.getNombre().equals(nombreUsuario)) {
                    index = i;
                    break;
                }
            }
        }
        if (index != -1) {
            keys[index] = null;
            values[index] = null;
            size--;
        }
    }

   public void removeDocument(String nombreDocumento) {
    for (int i = 0; i < capacity; i++) {
        if (values[i] != null && values[i] instanceof Lista) {
            Lista listaDocumentos = (Lista) values[i];
            Nodo aux = listaDocumentos.getpFirst();

            while (aux != null) {
                Documento documento = (Documento) aux.getDato();

                if (documento.getNombre().equals(nombreDocumento)) {
                    listaDocumentos.EliminarDoc(nombreDocumento);
                    break;
                }
                
                aux = aux.getpNext(); // Mover el incremento dentro del if
            }
        }
    }
}


}
