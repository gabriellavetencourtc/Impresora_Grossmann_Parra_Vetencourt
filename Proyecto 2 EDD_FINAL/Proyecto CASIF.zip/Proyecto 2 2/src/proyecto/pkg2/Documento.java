/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto.pkg2;

/**
 *
 * @author daniela
 */
public class Documento {

    private String usuario;
    private String nombre;
    private int tamaño;
    private String tipo;
    private int tiempo;


    public Documento(String usuario, String nombre, int tamaño, String tipo) {
        this.usuario = usuario;
        this.nombre = nombre;
        this.tamaño = tamaño;
        this.tipo = tipo;
        this.tiempo = tamaño*2;
    }


    public Documento(String nombre, int tamaño, String tipo) {
        this.nombre = nombre;
        this.tamaño = tamaño;
        this.tipo = tipo;
        this.tiempo = tamaño*2;
    }

    public String Imprimir() {
       String aux = "";
        aux+="DOCUMENTO "+ "\n";
        aux+=nombre+ "\n";
        aux+=tamaño+ "\n";
        aux+=tipo + "\n\n";
        return aux;

    }

    public int getTiempo() {
    return tiempo;
}

    public void setTiempo(int tiempo) {
        this.tiempo = tiempo;
    }

    public String getUsuario() {
        return usuario;
    }


    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getTamaño() {
        return tamaño;
    }

    public void setTamaño(int tamaño) {
        this.tamaño = tamaño;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    
  
    
}
