/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto.pkg2;

/**
 *
 * @author daniela
 */
public class MonticuloB {

    private Documento[] monticulo;
    private int actualSize;

    public MonticuloB() {
        this.monticulo = new Documento[50];
        actualSize = 0;
    }

    public Documento[] getMonticulo() {
        return monticulo;
    }

    public int getActualSize() {
        return actualSize;
    }

    public int padre(int i) {
        return (i - 1) / 2;
    }

    public int hijoIzquierdo(int i) {
        return 2 * i + 1;
    }

    public int hijoDerecho(int i) {
        return 2 * i + 2;
    }

    public void intercambiar(int i, int j) {
        Documento temp = monticulo[i];
        monticulo[i] = monticulo[j];
        monticulo[j] = temp;
    }

    public void insertar(Documento documento) {
        if (actualSize == monticulo.length) {
            System.out.println("El montículo está lleno");
            return;
        }

        int i = actualSize;
        monticulo[i] = documento;
        actualSize++;
        heapify(i);

        while (i != 0 && monticulo[padre(i)].getTiempo() > monticulo[i].getTiempo()) {
            intercambiar(i, padre(i));
            i = padre(i);
        }

    }

    public void eliminarMin() {
        if (actualSize == 0) {
            System.out.println("El montículo está vacío");
        }

        int indexMin = -1;
        for (int i = 0; i < actualSize; i++) {
            if (monticulo[i].equals(monticulo[0])) {
                indexMin = i;
                break;
            }
        }
        monticulo[indexMin] = monticulo[actualSize - 1];
        actualSize--;

        heapify(indexMin);
    }

    public void heapify(int i) {
        int izquierdo = hijoIzquierdo(i);
        int derecho = hijoDerecho(i);
        int menor = i;

        if (izquierdo < actualSize && monticulo[izquierdo].getTiempo() < monticulo[menor].getTiempo()) {
            menor = izquierdo;
        }

        if (derecho < actualSize && monticulo[derecho].getTiempo() < monticulo[menor].getTiempo()) {
            menor = derecho;
        }

        if (menor != i) {
            intercambiar(i, menor);
            heapify(menor);
        }
    }

    public boolean buscarPorNombre(String nombreDocumento) {
        for (int i = 0; i < actualSize; i++) {
            if (monticulo[i].getNombre().equals(nombreDocumento)) {
                return true;
            }
        }
        return false;
    }

    public void imprimirMonticulo() {
        System.out.println("Montículo actual:");
        for (int i = 0; i < actualSize; i++) {
            System.out.println("[" + monticulo[i].getNombre() + ", " + monticulo[i].getTiempo() + "] ");
        }
    }

    public String MostrarCola() {
        String aux = "";
        for (int i = 0; i < actualSize; i++) {
            aux += "[" + monticulo[i].getNombre() + ", " + monticulo[i].getTiempo() + "] ";
        }
        return aux;
    }

    public void imprimirMonticuloComoArbol() {
        System.out.println("Montículo como árbol:");

        int nivel = 0;
        int elementosEnNivel = 1;

        for (int i = 0; i < actualSize; i++) {
            if (i == elementosEnNivel - 1) {
                System.out.println();
                elementosEnNivel = elementosEnNivel * 2;
                nivel++;
            }

            int espacios = (int) Math.pow(2, actualSize - nivel) - 1;
            for (int j = 0; j < espacios; j++) {
                System.out.print(" ");
            }

            if (i != 0 && esHijoIzquierdo(i)) {
                System.out.print("/");
            } else if (i != 0 && esHijoDerecho(i)) {
                System.out.print("\\");
            } else {
                System.out.print(" ");
            }

            System.out.print(monticulo[i].getTamaño());
        }
        System.out.println();
    }

    public boolean esHijoIzquierdo(int i) {
        return i % 2 != 0;
    }

    public boolean esHijoDerecho(int i) {
        return i % 2 == 0;
    }

}
