/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto.pkg2;

/**
 *
 * @author gabriellavetencourt
 */
public class Lista<T> {

    private Nodo<T> pFirst;
    private int size;
    private Nodo<T> pLast;
    private Hashtable hs;

    public Lista() {
        this.pFirst = null;
        this.size = 0;
        this.pLast = null;
        this.hs = new Hashtable();
    }

    public Hashtable getHs() {
        return hs;
    }

    public boolean esVacio() {
        return pFirst == null;
    }

    public void InsertarFinal(T dato) {
        Nodo newnodo = new Nodo(dato);
        Nodo aux = pFirst;
        if (esVacio()) {
            pFirst = newnodo;
        } else {
            while (aux.getpNext() != null) {
                aux = aux.getpNext();
            }
            aux.setpNext(newnodo);
        }
        size++;
    }

    public void ImprimirDoc() {
        Nodo aux = pFirst;
        int cont = 1;
        if (esVacio()) {
            System.out.println("La lista es vacía");
        } else {
            while (aux != null) {
                Documento doc = (Documento) aux.getDato();
                System.out.println("DOCUMENTO " + cont);
                System.out.println(doc.getUsuario());
                System.out.println(doc.getNombre());
                System.out.println(doc.getTamaño());
                System.out.println(doc.getTipo() + "\n");

                aux = aux.getpNext();
                cont++;
            }
        }
    }

    public void ImprimirUs() {
        Nodo aux = pFirst;
        int cont = 1;
        if (esVacio()) {
            System.out.println("La lista es vacía");
        } else {
            while (aux != null) {
                Usuario us = (Usuario) aux.getDato();
                System.out.println("Usuario " + cont);
                System.out.println(us.getNombre());
                System.out.println(us.getTipo() + "\n");

                aux = aux.getpNext();
                cont++;
            }
        }

    }

    public String ImprimirDocPrueba() {
        Nodo aux1 = pFirst;
        int cont = 1;
        String aux = "";

        if (esVacio()) {
            aux += "La lista es vacía";
        } else {
            while (aux1 != null) {
                Documento doc = (Documento) aux1.getDato();
                aux += "DOCUMENTO " + cont + "\n";
                aux += "Nombre: " + doc.getNombre() + "\n";
                aux += "Tamaño: " + doc.getTamaño() + "\n";
                aux += "Tipo: " + doc.getTipo() + "\n\n";

                aux1 = aux1.getpNext();
                cont++;
            }
        }
        return aux;

    }

    public String ImprimirPorUsuario(String nombreUsuario) {
        Nodo aux1 = pFirst;
        int cont = 1;
        String aux = "";

        if (esVacio()) {
            aux += "La lista es vacía";
        } else {
            while (aux1 != null) {
                Documento doc = (Documento) aux1.getDato();
                if (doc.getUsuario().equalsIgnoreCase(nombreUsuario)) {
                    aux += "DOCUMENTO " + cont + "\n";
                    aux += "Nombre: " + doc.getNombre() + "\n";
                    aux += "Tamaño: " + doc.getTamaño() + "\n";
                    aux += "Tipo: " + doc.getTipo() + "\n\n";
                }
                aux1 = aux1.getpNext();
                cont++;
            }
        }
        return aux;

    }


    public String TextAreaUD(Lista ldoc) {
        String print = "";
        Nodo aux = pFirst;

        if (!esVacio()) {
            while (aux != null) {
                Usuario us = (Usuario) aux.getDato();
                print += "\n" + us.getNombre() + "-->" + us.getTipo() + "\n";
                print += "Documentos: \n";

                Nodo aux2 = ldoc.getpFirst();

                while (aux2 != null) {
                    Documento doc = (Documento) aux2.getDato();
                    if (us.getNombre().equalsIgnoreCase(doc.getUsuario())) {
                        print += doc.getNombre() + "\n";
                    }
                    aux2 = aux2.getpNext();
                }
                aux = aux.getpNext();
            }

        }
        return print;
    }


    public int getIndex(String nombre) {
        Nodo aux = pFirst;
        int index = 0;
        int noEncontrado = -1;

        while (aux != null) {
            Documento doc = (Documento) aux.getDato();
            if (doc.getNombre().equalsIgnoreCase(nombre)) {
                return index;
            }
            aux = aux.getpNext();
            index++;
        }
        return noEncontrado;
    }


    public void HT(Usuario usuario) {
        Nodo aux = pFirst;
        Lista<Documento> ldocAux = new Lista<>();

        if (esVacio()) {
            System.out.println("La lista es vacía");

        } else {
            while (aux != null) {

                Documento doc = (Documento) aux.getDato();
                if (doc.getUsuario().equalsIgnoreCase(usuario.getNombre())) {

                    Documento docAux = new Documento(doc.getNombre(), doc.getTamaño(), doc.getTipo());
                    ldocAux.InsertarFinal(docAux);

                }
                aux = aux.getpNext();
            }

        }
        ldocAux.ImprimirDoc();
        hs.put(usuario, ldocAux);
        hs.printHashtable();

    }

    public boolean buscarUsuario(String nombre) {
        Nodo aux = pFirst;
        if (!esVacio()) {
            while (aux != null) {
                Usuario us = (Usuario) aux.getDato();
                if (us.getNombre().equalsIgnoreCase(nombre)) {
                    return true;
                }
                aux = aux.getpNext();
            }

        }
        return false;
    }

    public void eliminarUsuario(String nombre) {
        Nodo actual = pFirst;
        Nodo anterior = null;

        while (actual != null && ((Usuario) actual.getDato()).getNombre().equalsIgnoreCase(nombre)) {
            pFirst = actual.getpNext();
            actual = pFirst;
        }
        if (!esVacio()) {
            while (actual != null) {
                Usuario us = (Usuario) actual.getDato();
                if (us.getNombre().equalsIgnoreCase(nombre)) {
                    anterior.setpNext(actual.getpNext());
                } else {
                    anterior = actual;
                }
                actual = actual.getpNext();
            }

        }

    }
    
    public void eliminarDocUs(String nombre){
        Nodo actual = pFirst;
        Nodo anterior = null;

        while (actual != null && ((Documento) actual.getDato()).getUsuario().equalsIgnoreCase(nombre)) {
            pFirst = actual.getpNext();
            actual = pFirst;
        }
        if (!esVacio()) {
            while (actual != null) {
                Documento doc = (Documento) actual.getDato();
                if (doc.getUsuario().equalsIgnoreCase(nombre)) {
                    anterior.setpNext(actual.getpNext());
                } else {
                    anterior = actual;
                }
                actual = actual.getpNext();
            }
        }
    }
    
    public void EliminarDoc(String nombreDoc){
        Nodo actual = pFirst;
        Nodo anterior = null;

        while (actual != null && ((Documento) actual.getDato()).getNombre().equalsIgnoreCase(nombreDoc)) {
            pFirst = actual.getpNext();
            actual = pFirst;
        }
        if (!esVacio()) {
            while (actual != null) {
                Documento doc = (Documento) actual.getDato();
                if (doc.getNombre().equalsIgnoreCase(nombreDoc)) {
                    anterior.setpNext(actual.getpNext());
                } else {
                    anterior = actual;
                }
                actual = actual.getpNext();
            }
        }   
    }

    public void EliminarFinal() {
        Nodo aux = pFirst;
        if (!esVacio()) {
            while (aux.getpNext().getpNext() != null) {
                aux = aux.getpNext();
            }
            aux.setpNext(null);
            size--;
        }
    }

    public Nodo<T> getpFirst() {
        return pFirst;
    }

    public void setpFirst(Nodo<T> pFirst) {
        this.pFirst = pFirst;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public Nodo<T> getpLast() {
        return pLast;
    }

    public void setpLast(Nodo<T> pLast) {
        this.pLast = pLast;
    }

}
