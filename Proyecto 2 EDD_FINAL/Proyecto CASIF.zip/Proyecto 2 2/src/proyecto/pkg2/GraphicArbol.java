/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto.pkg2;

/**
 *
 * @author gabriellavetencourt
 */
import java.awt.Graphics;
import javax.swing.JPanel;

public class GraphicArbol extends JPanel{
     private MonticuloB monticulo;
    public static final int DIAMETRO = 30;
    public static final int RADIO = DIAMETRO / 2;
    public static final int ANCHO = 30;
    public static final int NIVEL_Y = 50;
    public static final int ESPACIO_ENTRE_NODOS = 50;

    public void setMonticulo(MonticuloB monticulo) {
        this.monticulo = monticulo;
        repaint();
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        dibujarMonticulo(g, getWidth() / 2, NIVEL_Y, 0);
    }

    public void dibujarMonticulo(Graphics g, int x, int y, int indice) {
        if (indice < monticulo.getActualSize()) {
            g.drawOval(x, y, DIAMETRO, DIAMETRO);
            g.drawString(monticulo.getMonticulo()[indice].getNombre(), x + 8, y + 18);

            int hijoIzquierdoIndice = monticulo.hijoIzquierdo(indice);
            int hijoDerechoIndice = monticulo.hijoDerecho(indice);

            if (hijoIzquierdoIndice < monticulo.getActualSize()) {
                // Dibujar línea al hijo izquierdo
                int xIzquierdo = x - ESPACIO_ENTRE_NODOS;
                int yIzquierdo = y + ESPACIO_ENTRE_NODOS;
                g.drawLine(x + RADIO, y + RADIO, xIzquierdo + RADIO, yIzquierdo + RADIO);
                dibujarMonticulo(g, xIzquierdo, yIzquierdo, hijoIzquierdoIndice);
            }

            if (hijoDerechoIndice < monticulo.getActualSize()) {
                // Dibujar línea al hijo derecho
                int xDerecho = x + ESPACIO_ENTRE_NODOS;
                int yDerecho = y + ESPACIO_ENTRE_NODOS;
                g.drawLine(x + RADIO, y + RADIO, xDerecho + RADIO, yDerecho + RADIO);
                dibujarMonticulo(g, xDerecho, yDerecho, hijoDerechoIndice);
            }
        }
    }
    
//    private MonticuloB arbol;
//    public static final int DIAMETRO = 30;
//    public static final int RADIO = DIAMETRO/2;
//    public static final int ANCHO = 30;
//    
//    public void setArbol(MonticuloB arbol){
//        this.arbol = arbol;
//        repaint();
//        
//    }
//    
//    @Override
//    public void paint(Graphics g){
//        super.paint(g);
//        pintar(g, getWidth()/2, 20, arbol.raiz);   
//    }
//    
//    public void pintar(Graphics g, int x, int y, NodoArbol subarbol ){
//        if(subarbol!=null){
//            int EXTRA = arbol.nodosCompletos(subarbol) * ANCHO/2;
//            g.drawOval(x, y, DIAMETRO, DIAMETRO);
//            g.drawString(subarbol.dato.toString, x +12, y+18);
//            if(subarbol.izquierdo!=null){
//                g.drawLine(x, y + RADIO, x + RADIO -ANCHO - EXTRA, y+ ANCHO);
//            }
//            if(subarbol.derecho!=null){
//                g.drawLine(x+ DIAMETRO, y+RADIO, x+RADIO +ANCHO+EXTRA, y+ANCHO);
//            }
//            pintar(g, x- ANCHO - EXTRA , y+ ANCHO, subarbol.izquierdo);
//            pintar(g, x- ANCHO - EXTRA , y+ ANCHO, subarbol.derecho);
//        }
//    }
    
}
